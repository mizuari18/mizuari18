from django.urls import path
from. import views

urlpatterns = [
    path('layout/', views.layout, name='layout'),
    path('login/', views.login, name=('login')),
    path('contact/', views.contact, name=('contact')),
    
]