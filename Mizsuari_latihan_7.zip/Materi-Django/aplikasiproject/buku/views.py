from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .models import bukuModel

class bukuCreate(CreateView):

    # specify the model for create view
    model = bukuModel

    # specify the fields to be displayed

    fields = ['title', 'description', 'date', 'author', 'file']
 
class bukuList(ListView):
     
    # specify the model for list view
    model = bukuModel
    
class bukuDetailView(DetailView):
    # specify the model to use
    model = bukuModel
    
class bukuUpdateView(UpdateView):
    # specify the model you want to use
    model = bukuModel
 
    # specify the fields
    fields = [
        "title",
        "description",
        "date",
        "author",
        "file",
    ]
 
    # can specify success url
    # url to redirect after successfully
    # updating details
    success_url ="/"
    
class bukuDeleteView(DeleteView):
    # specify the model you want to use
    model = bukuModel
     
    # can specify success url
    # url to redirect after successfully
    # deleting object
    success_url ="/"
 
