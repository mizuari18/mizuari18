from django import forms
from .models import bukuModel


# creating a form
class bukuForm(forms.ModelForm):

	# create meta class
	class Meta:
		# specify model to be used
		model = bukuModel

		# specify fields to be used
		fields = [
			"title",
			"description",
			"date",
			"author",
   			"file",
		]
