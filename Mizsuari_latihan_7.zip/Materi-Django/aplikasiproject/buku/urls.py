# urls.py
from django.urls import path
from. http import MyView
from. views import bukuCreate
from. views import bukuList
from. views import bukuDetailView
from. views import bukuUpdateView
from. views import bukuDeleteView
urlpatterns = [
    path('form/', bukuCreate.as_view()),
    path('li/', bukuList.as_view()),
    path('<pk>/', bukuDetailView.as_view()),
    path('<pk>/update/', bukuUpdateView.as_view()),
    path('<pk>/hapus/', bukuDeleteView.as_view()),

]
