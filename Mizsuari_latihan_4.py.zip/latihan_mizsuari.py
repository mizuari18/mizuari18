#-------------------------------------------------------------------------------
#                                  Soal Latihan For             
#-------------------------------------------------------------------------------
# input [1, 2, 3, 4, 5]
# output [1, 4, 9, 16, 25]

# Buatlah function untuk menerima input lalu mengeluarkan output dengan kuadratu
def squares(int_list):
    squared_list = []
    
    for num in int_list:
        squared_list.append(num ** 2)
    
    print(squared_list) 
        

list_number = [1, 2, 3, 4, 5]
squares(list_number)

#---------------------------------------------------------------------------------
#                                  Soal Latihan If, elif, Else
#---------------------------------------------------------------------------------
# Input 90
# Output A
# Jika nilai 90 - 100 maka keluarnya A
# Jika nilai 80 - 89 maka keluarnya B
# Jika nilai 70 - 79 maka keluarnya C
# Jika nilai 60 - 69 maka keluarnya Remedial

# Buatlah function untuk mengklasifikasikan nilai siswa berdasarkan persyaratan diatas menggunakan if elif else
def penilaian_siswa(nilai):
    # Code dibawah sini
    # --------------------------------
   if nilai_siswa <= 100:
       print("A")
   elif nilai_siswa <= 89:
       print("B")
   elif nilai_siswa <= 79:
       print("C")
   else:
       print("Remedial")

    # --------------------------------

nilai_siswa = 90
penilaian_siswa(nilai_siswa)
#---------------------------------------------------------------------------------
#                                   Soal Latihan String
#---------------------------------------------------------------------------------
# input nama_depan = stephen
# input nama_belakang = leonardo
# output Stephen Leonardo

# Buatlah function untuk menerima nama depan dan nama belakang lalu mengeluarkan output nama_lengkap dengan huruf kapital di huruf awal
def nama_lengkap(nama_depan, nama_belakang):
    # Code dibawah sini
    # --------------------------------
        print(nama_depan.capitalize() + " " + nama_belakang.capitalize())

    #---------------------------------

nama_depan = "stephen"
nama_belakang = "leonardo"
nama_lengkap(nama_depan, nama_belakang)