from .models import Book
from .forms import BookForm
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

def user_logout(request):
    logout(request)
    return redirect('user_login')

def user_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None: # Jika user ada datanya / user tidak kosong
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')

def index(request):
    if request.method == 'GET':
        return render(request, 'index.html')
@login_required
def book_create(request):
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid: # Untuk mengecheck apakah data yang dikirim itu sesuai atau tidak
            book = form.save()
            book.save()
            return redirect('index')
    else:
        form = BookForm()
    return render(request, 'book_create.html', {'form': form})
@login_required
def book_list(request):
    books = Book.objects.all() # Mengkueri semua data pada database Book
    return render(request, 'book_list.html', {'books':books}) #{'books':books} - Mengirim data books ke HTML

 
def update(request, id):
    # dictionary for initial data with 
    # field names as keys
    context ={}
 
    # fetch the object related to passed id
    obj = get_object_or_404(Book, id = id)
 
    # pass the object as instance in form
    form = BookForm(request.POST or None, instance = obj)
 
    # save the data from the form and
    # redirect to detail_view
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/book-list/")
 
    # add form dictionary to context
    context["form"] = form
 
    return render(request, "update_book.html", context)    

def delete(request, id):
    # dictionary for initial data with 
    # field names as keys
    context ={}
 
    # fetch the object related to passed id
    obj = get_object_or_404(Book, id = id)
 
 
    if request.method =="POST":
        # delete object
        obj.delete()
        # after deleting redirect to 
        # home page
        return HttpResponseRedirect("/")
 
    return render(request, "delete_book.html", context)   