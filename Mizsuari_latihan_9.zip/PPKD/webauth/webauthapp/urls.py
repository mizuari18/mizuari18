from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.user_login, name='user_login'),
    path('logout/', views.user_logout, name='user_logout'),
    path('book-create', views.book_create, name='book_create'),
    path('book-list/', views.book_list, name='book_list'),
    path('<id>/update/', views.update, name='update'),
    path('<id>/delete/', views.delete, name='delete'),
    
]
