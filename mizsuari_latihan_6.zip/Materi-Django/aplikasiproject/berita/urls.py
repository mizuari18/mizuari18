from django.contrib import admin
from django.urls import path
from. import views
from. views import detail_view
from. views import delete_view
urlpatterns = [
    path('create/', views.create_view, name='cretae_view'),
    path('list/', views.list_view, name='list_view'),
    path('<id>', views.detail_view, name='detail_view'),
    path('<id>/update/', views.update_view, name='update view'),
    path('<id>/delete/', views.delete_view,name='delete view' ),
]
