from django.http import HttpResponse
from django.template import loader
# Create your views here.
def layout (request):
    template = loader.get_template('home.html')
    return HttpResponse(template.render())

def login (request):
    template = loader.get_template('login.html')
    return HttpResponse(template.render())

def contact (request):
    template = loader.get_template('contact.html')
    return HttpResponse(template.render())